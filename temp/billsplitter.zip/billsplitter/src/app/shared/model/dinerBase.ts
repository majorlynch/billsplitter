export interface DinerBase {
    key: number;
    name: string;
    amount: number;
    order: number;
    locked: boolean;
}